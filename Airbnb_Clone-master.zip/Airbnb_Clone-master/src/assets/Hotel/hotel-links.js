export const hotelinks = [
  {
    label:" Kamiminochi District, Japan",
    price:"2999.00",
    address:"115,kilometer away 5night .23-25 dec",
    img:"https://raw.githubusercontent.com/AVIVASHISHTA29/airbnbStarter/e696a5a729d5813b0d5b1ea731871941c7efd1b8/src/assets/hotels/hotel-1.jpeg",
    
  },
  {
    label:"Treehouse in Nago, Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://raw.githubusercontent.com/AVIVASHISHTA29/airbnbStarter/e696a5a729d5813b0d5b1ea731871941c7efd1b8/src/assets/hotels/hotel-2.jpeg"},
  {
    label:"Treehouse in Nago, Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://a0.muscache.com/im/pictures/e6fdaab3-391f-43b5-885b-902b7df93503.jpg?im_w=720"},
  {
    label:" Nago Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

    img: "https://a0.muscache.com/im/pictures/miso/Hosting-592291975749257694/original/a8459f2b-8c5f-4624-91bc-b4d230aacb01.jpeg?im_w=720"},
  {
    label:"Room in Lonavla, India",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://a0.muscache.com/im/pictures/1c566eb6-97ca-4f01-9f35-ea55e4c58acd.jpg?im_w=720"},
  {
    label:" Kamiminochi District, Japan",
    price:"2999.00",
    address:"115,kilometer away 5night .23-25 dec",
    img:"https://a0.muscache.com/im/pictures/miso/Hosting-50647280/original/9ea9db37-2a5e-4729-9a3d-c71c31b297f2.jpeg?im_w=720",
    
  },
  
  {
    label:"Treehouse in Nago, Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://a0.muscache.com/im/pictures/hosting/Hosting-992058045110075723/original/e68845e5-1405-46dc-a3c5-9c8894711e61.jpeg?im_w=720"},
  {
    label:" Nago Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

    img: "https://a0.muscache.com/im/pictures/f476e03e-a56f-439d-95fb-8116d72fecf3.jpg?im_w=720"},
  {
    label:"Room in Lonavla, India",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://a0.muscache.com/im/pictures/3249d684-600d-4201-a2c7-d4c79a19e5a3.jpg?im_w=720"},
  {
    label:" Kamiminochi District, Japan",
    price:"2999.00",
    address:"115,kilometer away 5night .23-25 dec",
    img:"https://a0.muscache.com/im/pictures/e6fdaab3-391f-43b5-885b-902b7df93503.jpg?im_w=720",
    
  },
 
  {
    label:" Nago Japan",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

    img: "https://a0.muscache.com/im/pictures/miso/Hosting-52329661/original/800aa635-16b7-4ceb-adbc-3d2445edd9dd.jpeg?im_w=720"},
  {
    label:"Room in Lonavla, India",
      price:"2999.00",
      address:"115,kilometer away 5night .23-25 dec",

  img:"https://a0.muscache.com/im/pictures/fffa2cf7-bb7c-4c45-b09d-22e4d24016f3.jpg?im_w=720"}
];